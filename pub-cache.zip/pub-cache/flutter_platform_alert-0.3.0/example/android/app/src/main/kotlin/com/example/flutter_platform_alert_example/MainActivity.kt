package com.example.flutter_platform_alert_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
