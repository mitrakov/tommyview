# 0.0.1

  * Publish initial version.

# 0.0.2

  * Add api document and will pop scope.

# 0.0.3

  * Change passing as widget.

# 0.1.0

  * Add example main.

# 0.1.1

  * Add `hintText`, `maxLines` and `minLines` properties.

# 0.1.2

  * Add `obscureText` and `obscuringCharacter` properties. Huge Thanks! @tpillow

# 0.1.3

  * Add `textCapitalization` property. Huge Thanks! @joachimvalente

# 0.1.4

  * Add `keyboardType`, `textInputAction` property.

# 1.0.0

  * Apply null safety.

# 1.0.1

  * Change default value of autofocus to true.

# 1.0.2

  * Add `onEditingComplete` property.(#6)

# 1.0.3

  * Fix for returning initialValue.(#8) Huge Thanks! @gnilron

# 1.0.4

  * Add `showPasswordIcon`, `barrierDismissible` properties.
  * Simpler fix for returning initialValue if no changes.
  * Huge Thanks! @FRFGCCEVCV

# 1.0.5

  * Add `validator` property.(#10)
  * Huge Thanks! @cmorsucci

# 1.0.6

  * Add `isSelectedInitialValue` property.(#11)
  * Huge Thanks! @hippyau

# 1.0.7

  * Fix the validator issue.(#12)
  * Huge Thanks! @dakamojo 

# 1.0.8

  * Update example usage.(#14)
  * Huge Thanks! @mjablecnik

# 1.0.9

  * Add `textAlign` property.(#16)
  * Huge Thanks! @FelipeSamuel
