import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('prompt', (WidgetTester tester) async {
    await tester.pump();
});
}
