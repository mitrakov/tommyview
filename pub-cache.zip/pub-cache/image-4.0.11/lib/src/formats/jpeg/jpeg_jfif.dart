import '../../util/input_buffer.dart';

class JpegJfif {
  int? majorVersion;
  int? minorVersion;
  int? densityUnits;
  int? xDensity;
  int? yDensity;
  late int thumbWidth;
  late int thumbHeight;
  InputBuffer? thumbData;
}
