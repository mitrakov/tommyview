import 'psd_effect.dart';

class PsdDropShadowEffect extends PsdEffect {
  int? blur;
  int? intensity;
  int? angle;
  int? distance;
  List<int>? color;
  String? blendMode;
  bool? globalAngle;
  int? opacity;
  List<int>? nativeColor;
}
