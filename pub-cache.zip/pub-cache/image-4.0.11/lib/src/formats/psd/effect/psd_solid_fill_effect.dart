import 'psd_effect.dart';

class PsdSolidFillEffect extends PsdEffect {
  String? blendMode;
  List<int>? color;
  int? opacity;
  List<int>? nativeColor;
}
