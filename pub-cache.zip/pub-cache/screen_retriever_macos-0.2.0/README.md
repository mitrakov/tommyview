# screen_retriever_macos

[![pub version][pub-image]][pub-url]

[pub-image]: https://img.shields.io/pub/v/screen_retriever_macos.svg
[pub-url]: https://pub.dev/packages/screen_retriever_macos

The macos implementation of [screen_retriever](https://pub.dev/packages/screen_retriever).

## License

[MIT](./LICENSE)
