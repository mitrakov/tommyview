package com.fluttercandies.extendedImageExample

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()