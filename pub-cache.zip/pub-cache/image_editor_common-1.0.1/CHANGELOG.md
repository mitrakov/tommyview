# CHANGELOG

## 1.0.1

Fix:

- macOS
  - The problem of `DrawOption`.

## 1.0.0

- Initial release.
The version code was copied from 1.2.0 of the [image_editor][] plugin.

[image_editor]: https://pub.dev/packages/image_editor
