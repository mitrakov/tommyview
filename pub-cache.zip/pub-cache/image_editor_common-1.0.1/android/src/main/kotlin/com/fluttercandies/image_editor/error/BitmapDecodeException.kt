package com.fluttercandies.image_editor.error

class BitmapDecodeException : RuntimeException()
