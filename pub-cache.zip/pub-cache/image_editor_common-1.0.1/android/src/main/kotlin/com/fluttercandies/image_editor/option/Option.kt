package com.fluttercandies.image_editor.option

interface Option {
    fun canIgnore(): Boolean = false
}
