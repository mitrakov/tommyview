//
// Created by jinglong cai on 2022/7/11.
//

#import <Foundation/Foundation.h>


@interface FICommonUtils : NSObject

+ (NSMutableArray *)pointToArray:(CGPoint)point;

+ (CGPoint)arrayToPoint:(NSArray *)arr;

@end