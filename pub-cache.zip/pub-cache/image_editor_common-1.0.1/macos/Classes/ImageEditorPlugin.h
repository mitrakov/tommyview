#import "FIImport.h"

@interface ImageEditorPlugin : NSObject <FlutterPlugin>
@end
