/// Generate by [resource_generator](https://github.com/CaiJingLong/flutter_resource_generator) library.
/// PLEASE DO NOT EDIT MANUALLY.
class R {

  /// ![preview](file:///Volumes/Samsung-T5/code/flutter/plugins/flutter_image_editor/example/./assets/dst.png)
  static const String ASSETS_DST_PNG = 'assets/dst.png';

  /// ![preview](file:///Volumes/Samsung-T5/code/flutter/plugins/flutter_image_editor/example/./assets/have-exif-3.jpg)
  static const String ASSETS_HAVE_EXIF_3_JPG = 'assets/have-exif-3.jpg';

  /// ![preview](file:///Volumes/Samsung-T5/code/flutter/plugins/flutter_image_editor/example/./assets/icon.png)
  static const String ASSETS_ICON_PNG = 'assets/icon.png';

  /// ![preview](file:///Volumes/Samsung-T5/code/flutter/plugins/flutter_image_editor/example/./assets/src.png)
  static const String ASSETS_SRC_PNG = 'assets/src.png';
}
