//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import image_editor_common
import path_provider_macos

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  ImageEditorPlugin.register(with: registry.registrar(forPlugin: "ImageEditorPlugin"))
  PathProviderPlugin.register(with: registry.registrar(forPlugin: "PathProviderPlugin"))
}
