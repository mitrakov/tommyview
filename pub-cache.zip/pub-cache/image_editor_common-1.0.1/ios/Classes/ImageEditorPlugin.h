#import <Flutter/Flutter.h>

@interface ImageEditorPlugin : NSObject <FlutterPlugin>
@end
