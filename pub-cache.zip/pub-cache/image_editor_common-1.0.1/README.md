# image_editor_common

The image_editor_common package is common implemented for the [image_editor][] package.

Support the following platforms:

- Android
- iOS
- macOS

[image_editor]: https://github.com/fluttercandies/flutter_image_editor
