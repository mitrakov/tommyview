#import <Flutter/Flutter.h>

@interface FlutterPlatformAlertPlugin : NSObject<FlutterPlugin>
@end
