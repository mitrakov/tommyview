abstract class FileContent {
  List<int> get content;
}
