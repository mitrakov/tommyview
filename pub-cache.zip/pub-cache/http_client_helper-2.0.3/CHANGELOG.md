## 2.0.3

* Fix cancel token not working #6

## 2.0.2

* Fix error that the type parameter should not nullable at Future.delayed
## 2.0.1

* Fix error that nvalid argument (onError)
  
## 2.0.0

* support null-safety
  
## 1.0.0

* add analysis_options.yaml
## 0.2.1

* public HttpClientHelper.httpClient, so that you can new client base on your case.
  dart:io =>IOClient
  dart:html=>BrowserClient

## 0.2.0

* add OnTimeout onTimeout parameter for all method

## 0.1.8

* add other method of http

## 0.1.7

* add timeLimit for timeout

## 0.1.5

* format code

## 0.1.4

* remove map to string for post

## 0.1.3

* make all http_client_helper darts as library http_client_helper

## 0.1.2

* Fix retries for retry helper.

## 0.1.1

* Handle map body.

## 0.1.0

* Upgrade Some Commments.

## 0.0.1

* Initial Open Source release.