// iuiautomationexpandcollapsepattern.dart

// THIS FILE IS GENERATED AUTOMATICALLY AND SHOULD NOT BE EDITED DIRECTLY.

// ignore_for_file: unused_import
// ignore_for_file: constant_identifier_names, non_constant_identifier_names
// ignore_for_file: no_leading_underscores_for_local_identifiers

import 'dart:ffi';

import 'package:ffi/ffi.dart';

import '../callbacks.dart';
import '../combase.dart';
import '../constants.dart';
import '../exceptions.dart';
import '../guid.dart';
import '../macros.dart';
import '../propertykey.dart';
import '../structs.g.dart';
import '../utils.dart';
import '../variant.dart';
import '../win32/ole32.g.dart';
import 'iunknown.dart';

/// @nodoc
const IID_IUIAutomationExpandCollapsePattern =
    '{619be086-1f4e-4ee4-bafa-210128738730}';

/// Provides access to a control that can visually expand to display
/// content, and collapse to hide content.
///
/// {@category com}
class IUIAutomationExpandCollapsePattern extends IUnknown {
  // vtable begins at 3, is 4 entries long.
  IUIAutomationExpandCollapsePattern(super.ptr);

  factory IUIAutomationExpandCollapsePattern.from(IUnknown interface) =>
      IUIAutomationExpandCollapsePattern(
        interface.toInterface(IID_IUIAutomationExpandCollapsePattern),
      );

  int expand() => (ptr.ref.vtable + 3)
      .cast<Pointer<NativeFunction<Int32 Function(Pointer)>>>()
      .value
      .asFunction<int Function(Pointer)>()(ptr.ref.lpVtbl);

  int collapse() => (ptr.ref.vtable + 4)
      .cast<Pointer<NativeFunction<Int32 Function(Pointer)>>>()
      .value
      .asFunction<int Function(Pointer)>()(ptr.ref.lpVtbl);

  int get currentExpandCollapseState {
    final retValuePtr = calloc<Int32>();

    try {
      final hr =
          (ptr.ref.vtable + 5)
              .cast<
                Pointer<
                  NativeFunction<Int32 Function(Pointer, Pointer<Int32> retVal)>
                >
              >()
              .value
              .asFunction<int Function(Pointer, Pointer<Int32> retVal)>()(
            ptr.ref.lpVtbl,
            retValuePtr,
          );

      if (FAILED(hr)) throw WindowsException(hr);

      final retValue = retValuePtr.value;
      return retValue;
    } finally {
      free(retValuePtr);
    }
  }

  int get cachedExpandCollapseState {
    final retValuePtr = calloc<Int32>();

    try {
      final hr =
          (ptr.ref.vtable + 6)
              .cast<
                Pointer<
                  NativeFunction<Int32 Function(Pointer, Pointer<Int32> retVal)>
                >
              >()
              .value
              .asFunction<int Function(Pointer, Pointer<Int32> retVal)>()(
            ptr.ref.lpVtbl,
            retValuePtr,
          );

      if (FAILED(hr)) throw WindowsException(hr);

      final retValue = retValuePtr.value;
      return retValue;
    } finally {
      free(retValuePtr);
    }
  }
}
