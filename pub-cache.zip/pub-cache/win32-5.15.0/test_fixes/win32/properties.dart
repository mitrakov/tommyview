import 'package:win32/win32.dart';

final $0 = isCOMInitialized;
