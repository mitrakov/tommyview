package com.fluttercandies.flutter_image_editor_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
