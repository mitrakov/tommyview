import 'dart:io';

final String tmpPath = Directory.systemTemp.createTempSync().path;
