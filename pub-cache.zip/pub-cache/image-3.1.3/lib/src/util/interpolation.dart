// enum Interpolation

enum Interpolation { nearest, linear, cubic, average }
