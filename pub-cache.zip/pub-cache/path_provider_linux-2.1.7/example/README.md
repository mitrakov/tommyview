# path_provider_linux_example

Demonstrates how to use the path_provider_linux plugin.
