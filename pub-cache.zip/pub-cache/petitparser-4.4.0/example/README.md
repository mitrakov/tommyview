PetitParser Examples
====================

For more complicated examples see the official [GitHub repository](https://github.com/petitparser/dart-petitparser/tree/main/example).
 
This directory contains the command-line calculator that is described in the introductory tutorial:
 
    dart petitparser/example/calc.dart "1 + 2 * 3"
