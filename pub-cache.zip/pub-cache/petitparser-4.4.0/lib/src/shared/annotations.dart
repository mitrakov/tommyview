const inlineVm = pragma('vm:prefer-inline');
const inlineJs = pragma('dart2js:tryInline');
