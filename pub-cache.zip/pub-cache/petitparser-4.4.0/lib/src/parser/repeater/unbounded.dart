/// An [int] used to mark an unbounded maximum repetition.
const int unbounded = 9007199254740991; // Number.MAX_SAFE_INTEGER
